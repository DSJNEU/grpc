package com.suns.service;

import com.google.protobuf.ProtocolStringList;
import com.suns.HelloProto;
import com.suns.HelloServiceGrpc;
import io.grpc.stub.StreamObserver;

public class HelloServiceImpl extends HelloServiceGrpc.HelloServiceImplBase{
    @Override
    public void hello(HelloProto.HelloRequest request, StreamObserver<HelloProto.HelloResponse> responseObserver){
        String name = request.getName();
        System.out.println("name parameter"+name);
        HelloProto.HelloResponse.Builder builder = HelloProto.HelloResponse.newBuilder();
        builder.setResult("hello"+name);
        HelloProto.HelloResponse helloResponse = builder.build();
        responseObserver.onNext(helloResponse);
        responseObserver.onCompleted();

    }
    public void hello1(HelloProto.HelloRequest1 request, StreamObserver<HelloProto.HelloResponse1> responseObserver){
        ProtocolStringList nameList = request.getNameList();
        for(String name:nameList){
            System.out.println("name parameter "+name);
        }
        System.out.println("helloserviceimp.hello1");
        HelloProto.HelloResponse1.Builder builder = HelloProto.HelloResponse1.newBuilder();
        builder.setResult("ok");
        HelloProto.HelloResponse1 helloResponse = builder.build();
        responseObserver.onNext(helloResponse);//回传客户端
        responseObserver.onCompleted();//通知客户端响应完成
    }

    @Override
    public void c2ss(HelloProto.HelloRequest request, StreamObserver<HelloProto.HelloResponse> responseObserver) {
        String name  = request.getName();
        System.out.println("name = "+name);
        for (int i = 0; i <9 ; i++) {
            HelloProto.HelloResponse.Builder builder = HelloProto.HelloResponse.newBuilder();
            builder.setResult("hello "+name+" i = "+i);
            HelloProto.HelloResponse helloResponse = builder.build();
            responseObserver.onNext(helloResponse);

            try  {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        responseObserver.onCompleted();
    }
    public StreamObserver<HelloProto.HelloRequest> cs2ss(StreamObserver<HelloProto.HelloResponse> responseObserver){
        return new StreamObserver<>() {
            @Override
            public void onNext(HelloProto.HelloRequest helloRequest) {
                System.out.println("接受到了客户断提交的消息 " + helloRequest.getName());
                responseObserver.onNext(HelloProto.HelloResponse.newBuilder().setResult("response "+helloRequest.getName()).build());
            }

            @Override
            public void onError(Throwable throwable) {

            }

            @Override
            public void onCompleted() {
                System.out.println("接受完毕，发送到服务端");
                responseObserver.onCompleted();
            }
        };
    }

    public StreamObserver<HelloProto.HelloRequest> cs2s(StreamObserver<HelloProto.HelloResponse> requestObserver){
        return new StreamObserver<>() {
            @Override
            public void onNext(HelloProto.HelloRequest helloRequest) {
                System.out.println("接收到了服务端的一条消息 " +  helloRequest.getName());
            }

            @Override
            public void onError(Throwable throwable) {

            }

            @Override
            public void onCompleted() {
                System.out.println("接收了所有的消息，发送到服务端");
                HelloProto.HelloResponse.Builder builder = HelloProto.HelloResponse.newBuilder();
                builder.setResult("ok");
                HelloProto.HelloResponse helloResponse = builder.build();
                requestObserver.onNext(helloResponse);
                requestObserver.onCompleted();

            }
        };
    }
}
