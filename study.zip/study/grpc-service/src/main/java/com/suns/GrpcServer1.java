package com.suns;

import com.suns.service.HelloServiceImpl;
import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;

public class GrpcServer1 {
    public static void main(String[] args) {
        ServerBuilder<?> serverBuilder = ServerBuilder.forPort(8080);
        serverBuilder.addService(new HelloServiceImpl());
        Server server  = serverBuilder.build();
        try {
            server.start();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            server.awaitTermination();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
