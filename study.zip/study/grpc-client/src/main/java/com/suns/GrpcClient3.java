package com.suns;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.Iterator;

public class GrpcClient3 {
    public static void main(String[] args) {
      ManagedChannel managedChannel1 = ManagedChannelBuilder.forAddress("localhost",8080).usePlaintext().build();
      try{
          HelloServiceGrpc.HelloServiceBlockingStub helloService = HelloServiceGrpc.newBlockingStub(managedChannel1);//创建一个代理
          HelloProto.HelloRequest.Builder builder = HelloProto.HelloRequest.newBuilder();
          builder.setName("dsj");
          HelloProto.HelloRequest helloRequest = builder.build();
          Iterator<HelloProto.HelloResponse> helloResponses = helloService.c2ss(helloRequest);
          while (helloResponses.hasNext()){
              HelloProto.HelloResponse helloResponse = helloResponses.next();
              System.out.println("helloResponse() = "+helloResponse.getResult());
          }
      } catch (Exception e) {
          throw new RuntimeException(e);
      }
      finally {
          managedChannel1.shutdown();
      }
    }
}
