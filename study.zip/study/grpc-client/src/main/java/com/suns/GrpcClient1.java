package com.suns;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class GrpcClient1 {
    public static void main(String[] args) {
        ManagedChannel  channel = ManagedChannelBuilder.forAddress("localhost",8080).usePlaintext().build();
        try {
            HelloServiceGrpc.HelloServiceBlockingStub helloService = HelloServiceGrpc.newBlockingStub(channel);
            HelloProto.HelloRequest.Builder builder = HelloProto.HelloRequest.newBuilder();
            builder.setName("dsj");
            HelloProto.HelloRequest helloRequest = builder.build();
            HelloProto.HelloResponse  helloResponse = helloService.hello(helloRequest);
            String result = helloResponse.getResult();
            System.out.println("result = "+result);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            channel.shutdown();
        }
    }
}
