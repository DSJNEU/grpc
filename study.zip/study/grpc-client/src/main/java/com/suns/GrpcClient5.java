package com.suns;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

import java.util.concurrent.TimeUnit;

public class GrpcClient5 {
    public static void main(String[] args) {
        ManagedChannel  channel = ManagedChannelBuilder.forAddress("localhost",8080).usePlaintext().build();
        try{
            HelloServiceGrpc.HelloServiceStub helloService = HelloServiceGrpc.newStub(channel);
            StreamObserver<HelloProto.HelloRequest> helloRequestStreamObserver = helloService.cs2s(new StreamObserver<>() {
                @Override
                public void onNext(HelloProto.HelloResponse helloResponse) {
                    System.out.println("服务端响应内容为 " + helloResponse.getResult());
                }

                @Override
                public void onError(Throwable throwable) {

                }

                @Override
                public void onCompleted() {
                    System.out.println("服务端响应结束，根据需要在这里操作数据");
                }
            });

            for (int i = 0; i <10; i++) {
                HelloProto.HelloRequest.Builder  builder = HelloProto.HelloRequest.newBuilder();
                builder.setName("dsj " + i);
                HelloProto.HelloRequest helloRequest = builder.build();
                helloRequestStreamObserver.onNext(helloRequest);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            helloRequestStreamObserver.onCompleted();
            channel.awaitTermination(10, TimeUnit.SECONDS);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            channel.shutdown();
        }
    }
}
