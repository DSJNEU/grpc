package com.suns;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class GrpcClient2 {
    public static void main(String[] args) {
        ManagedChannel  channel = ManagedChannelBuilder.forAddress("localhost",8080).usePlaintext().build();
        try {
            HelloServiceGrpc.HelloServiceBlockingStub helloService = HelloServiceGrpc.newBlockingStub(channel);
            HelloProto.HelloRequest1.Builder builder = HelloProto.HelloRequest1.newBuilder();
            builder.addName("dsj1");
            builder.addName("dsj1");
            builder.addName("dsj1");
            builder.addName("dsj1");
            HelloProto.HelloRequest1 helloRequest1 = builder.build();
            HelloProto.HelloResponse1  helloResponse1 = helloService.hello1(helloRequest1);
            String result = helloResponse1.getResult();
            System.out.println("result = "+result);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            channel.shutdown();
        }
    }
}
